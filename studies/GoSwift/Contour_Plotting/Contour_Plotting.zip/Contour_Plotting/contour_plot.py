import sys
import contour

input_file = sys.argv[-1]

contour.run_plot(input_file)


