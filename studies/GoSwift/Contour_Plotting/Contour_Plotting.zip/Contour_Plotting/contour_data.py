import numpy as np
import math as ma

""" The data_import function is meant to allow the user of the contour module
to calculate data however the user would like and return it in the correct form
for use in the contour module.

Parameters
------------------------------------------------------------------------
N: number of data points per axis. i.e. N=100 gives 100 x 100 grid
xl: lower bound of x-axis data
xu: upper bound of x-axis data
yl: lower bound of y-axis data
yu: upper bound of y-axis data

Returns
------------------------------------------------------------------------
A: 1-D array of length N containing x-axis values
B: 1-D array of length N containing y-axis values
C: 1-D array of 2-D arrays containing z-axis values for each x-y pair for each
   data series. size of each 2-D array: NxN size of C: number of desired data
   series. Note: The order of the data series in the array C should match the
   order of the data series formatting in the input file to the contour module.
"""

def data_import(N,xl,xu,yl,yu):

    # Calculate Data here

    # Example Data
    A=np.linspace(xl, xu, N)
    B=np.linspace(yl, yu, N)

    C1=np.zeros((N, N), dtype=np.float64)
    C2=np.zeros((N, N), dtype=np.float64)
    for i in range(0, N):
        for j in range(0, N):
            C1[i, j] = A[i]*B[j]
            C2[i, j] = A[i]**2*B[j]

    C=[C1, C2]

    return A,B,C # where C=[C1, C2, C3, etc...]


